---
name: supermarket-poster
description: 超市/生鲜门店促销海报生成与打印技能。通过 智百威下发工具服务(bw-scale MCP) 连接器查询门店信息和商品数据，支持多种海报类型（整版活动彩页、分组商品彩页、多品海报/价签、单品海报/价签、纯文字海报...），根据商品数量与素材自动选择类型，生成美观专业的 A4/A5、竖版/横版、促销/正价的海报并发送到打印机打印，若指定生成手机/朋友圈海报时只需输出图片。触发词：超市海报、打印海报、商品海报、商品价签、促销海报、生鲜海报、水果海报、单品海报、彩页。
---

# 超市促销海报生成技能

## 工作流程

### 1. MCP 连接器就绪检查

bw-scale MCP 连接器默认 endpoint 为 `http://127.0.0.1:7688/mcp`。如工具不可用，通过直接 HTTP POST JSON-RPC 调用：

```
POST http://127.0.0.1:7688/mcp
Content-Type: application/json
Body: {"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"<tool_name>","arguments":{...}}}
```

如连接失败，提示用户确认智百威下发工具服务程序是否已启动并登录（默认端口7688）。

### 2. 查询门店信息

调用 `query_shop`（无参数）。**返回的门店字段都在 `ret_data` 里面**（例如 `ret_data.branch_name`、`ret_data.branch_url`），不是平铺在顶层：
- `branch_name`：门店名称
- `branch_tel`：联系电话
- `branch_addr`：门店地址
- `branch_url`：线上商城地址（用于生成二维码）
- `branch_memo`：门店备注
- `branch_logo_base64`：门店 logo 的 base64（保存为 png 文件）

将 `branch_logo_base64` 解码保存为 `branch_logo.png`。
`branch_url` 即二维码内容：**不必自己在 HTML 里画二维码**——打印时由 `poster_print` 的 `qrcode_text` 参数自动叠加（推荐，位置更准）。
如确需单独的二维码图片，调用本地工具 `get_qrcode`（`text=branch_url`、`size=300`、`format=path`），返回的 `image_path` 可直接使用；该工具离线可用，不要依赖外网二维码接口。

### 3. 查询商品

调用 `query_item`，关键参数：
- `keyword`：匹配**拼音助记码**（如 BLM=菠萝蜜），不是中文名称
- `only_spec=1`：只查特价商品
- `limit`：返回条数
- 如需更多商品，换关键词多次查询

先用 `only_spec=1` 查特价商品，再根据需要查询常规商品。记录每个商品的：名称、价格、单位、图片URL。

商品图片用 `image_search` 搜索或从商品数据中获取，下载保存到工作目录。

**缺图商品的占位处理（重要）**：对每个商品依次尝试——① 商品数据自带的图片URL；② `image_search` 搜索结果。两者都拿不到真实图时，**回退用 `image_gen` 生成一张卡通/示意占位图**，并给该商品打标记 `ai_placeholder=true`（同时记录其品名、条码、subno，供最后提示用户配图）。这样"带商品图"的海报（单品/多品/彩页）即便个别商品缺图也能照常出图，不会卡住流程。

### 3.5 （可选）浏览云端共享海报模板

若用户想使用别人分享 / 云端已有的海报模板作为起点（而不是从 assets 模板从零生成），调用 `query_cloud_templates`：
- `keyword`：按模板名模糊搜索（如"中秋""榴莲"）
- `is_my=1`：只看本人上传过的模板
- `page_index` / `page_size`：分页（默认每页 20）
- 默认只看海报类 `pst_html_pop_style`（soft_ver=`pstapp`）共享模板（与下发工具上传 / 云市场口径一致）

返回 `ret_data[]` 含 `tpl_name`、`tpl_uid`、`img_url`、`tpl_url`（云端绝对地址，可直接下载预览）。把模板真正下载并导入「下发工具-海报模块」通常在云市场界面（GUI）完成；本接口仅供 AI 列举 / 向用户推荐，便于用户挑选后再在界面内导入。

### 4. 判定海报类型（关键步骤）

按**商品数量 + 有无商品图**选择类型，从 `assets/` 复制对应模板作为起点：

| 商品数 | 有商品图 | 类型 | 模板 | 画布 |
|--------|---------|------|------|------|
| 1 个 | 有 | **单品海报**（大字报，价格最大化） | `poster-single.html` | A4 1240×1754 |
| 1 个 | 无 | **文字海报**（纯排版大字） | `poster-text.html` | A4 1240×1754 |
| 2~8 个 | 有 | **多品海报**（宫格：2/4/6/8 宫格） | `poster-multi.html` | A4（2×2）或 A5（874×1240，2×2/4×2） |
| 2~8 个 | 无 | **文字海报**（列表式价签） | `poster-text.html` | A4 1240×1754 |
| 9 个以上 | 有 | **彩页**（整版网格，含主视觉） | `poster-flyer.html` | A4 1240×1754 |
| 9 个以上 | 无 | **文字海报**（分类列表 + 大价格） | `poster-text.html` | A4 1240×1754 |

用户明确指定类型/样式时以用户为准；用户给了参考图时优先按参考图版式，但仍须遵守 poster-types.md 的美观规范（价格层级、划线原价、标签角标等）。

### 5. 确定主题配色

按活动性质选择主题（在模板 CSS 顶部改 `--c-main/--c-deep/--c-accent` 三个变量即可整体换肤）：
- 节日/开业/店庆/国庆/春节：喜庆红（红底金黄标题）
- 日常生鲜/周末特惠：超市绿或清爽蓝
- 秋：深蓝+金黄；春：亮蓝+橙；夏：清凉蓝绿
- 未指明时：优先结合当天日期就近节日，否则用默认促销红或超市绿

详细主题色值、分区尺寸、各类型排版规范见 [references/poster-types.md](references/poster-types.md)。



### 5.1 联网搜索风格参考（生成海报前优先执行）

生成任何海报前，**优先联网搜索**当前最新、最潮、效果最好的超市/生鲜彩页与促销海报设计参考，再结合本技能包内置风格确定版式与配色。这是产出"不土、跟得上潮流"海报的关键前置步骤。

1. 用智能体联网搜索能力检索当下趋势（如"超市彩页 设计趋势 / 生鲜促销海报 / 海报排版"，**年份用当前实际年份动态拼接，切勿写死**，以免来年过时），收集流行**版式结构**与**配色规律**（如高饱和红金撞色、多巴胺配色、满版圆角卡片网格、超大描边标题、价格黄底牌等）。
2. **只借鉴版式与配色"规律"**，不得整张下载套用网上成品海报图（版权、水印、低清三处皆坑）。
3. 将搜到的版式规律**抽象后落到本技能包的 HTML 模板**（`assets/poster-*.html`）：调整分区尺寸、网格列数、角标位置、字号层级等 CSS 结构，而非搬运别人版面；配色只改模板顶部 CSS 变量（`--c-main`/`--c-deep`/`--c-accent`/底色），可对照 `references/poster-types.md` 的"潮流风格预设"表。
4. 主视觉背景/插画**必须用 `image_gen` 原创生成**（无文字、留出标题空间），替换模板里注释掉的 `hero_bg.png`，不得直接下载网上背景图。
5. 商品/门店/价格数据永远来自本地商品库（`query_item`）与 `query_shop`，不在网上抄文案。

> 版式参考 ≠ 成品套用：学"结构规律"自己写 HTML/CSS 实现为自创、无侵权；下载别人 PNG/JPG 直接打印则带水印/低清且可能侵权，违反本技能包约束。

### 6. 生成海报 HTML

- **先用 `{{...}}` 占位符写模板**（详见 [references/poster-template-format.md](references/poster-template-format.md)），**不要直接把真实数据写死进 HTML**。
  商品列表用 `{{#items}}...{{/items}}` 循环；门店/活动用 `{{branch_name}}`/`{{activity_title}}` 等标量；单品海报循环外用 `{{item_name}}`/`{{price_int}}` 等即可（引擎自动注入第一件商品）。
- 立即预览/打印用的"渲染副本"：把占位符替换成真实数据后交给 Chrome 渲染；**但 `save_poster_template` 的 `html` 必须保留占位符原样**（否则模板永久静态、换商品不刷新）。
- 纯 HTML+CSS 精确布局（不用 AI 背景叠加，避免对齐问题）。
- 美观底线（所有类型通用）：
  - **价格是视觉焦点**：整数部分特大号红色加粗，小数和"元/斤"缩小；有原价时必须划线对比。
  - 商品卡片：白底圆角 + 阴影，图片区 `object-fit: contain` 白底衬图（生鲜图多为白底图，cover 会裁切主体）。
  - 角标/飘带（惊爆价、买一送一、限购、特惠等）增加促销氛围，但每张海报 ≤3 种角标，避免杂乱。
  - 主视觉标题用 `-webkit-text-stroke` 描边 + 投影做出立体感，可以使用免费商用好看的字体。
  - 商品名与图片必须一一对应，渲染后检查。

主视觉背景可用 `image_gen` 生成卡通促销场景（按主题色调），作为 hero 区域背景图。

### 7. 渲染为图片

用 Chrome headless 渲染：
```
chrome.exe --headless --disable-gpu --screenshot=输出.png --window-size=1240,1754 --default-background-color=FFFFFFFF "file:///html路径"
```

渲染后必须 Read 截图检查：商品名与图片是否对应、布局是否对齐、有无文字溢出或截断、价格是否醒目。不满意则改 HTML 重渲（最多 2~3 轮）。

### 8. 打印

调用 `poster_print`：
- `image_path`：海报 png 绝对路径
- `qrcode_text`：填 `branch_url`（本软件自动把二维码叠加到海报上，默认右下角）
- `qrcode_pos`：`bottom-right`(默认) / `top-right` / `top-left` / `bottom-left` / `center`
- `qrcode_size`：二维码边长(mm)，默认 30
- `qrcode_margin`：距页边距(mm)，默认 5
- `printer`：打印目标机名，取值来自 `query_printer`；不确定就留空(=系统默认打印机)
- `fit`：`page`
- `orientation`：`portrait`

如 MCP 工具不可用，用步骤 1 的直接 HTTP 方式调用。

### 8.5 提示用户给缺图商品配图（建议主动询问）

打印（步骤 8）完成后，**检查本次海报中所有 `ai_placeholder=true` 的商品**。若全部商品都有真实图，跳过本步；若有缺图商品，主动问用户一句：

> **"本次海报中以下 N 个商品（榴莲、车厘子…）没有查到真实商品图，用的是 AI 生成的占位图。要不要现在给它们配真实商品图？"**

- **用户要配图**：让用户提供真实商品图（或授权你用 `image_search` 重新检索 / 换关键词再查），用真实图替换对应占位图后，**重新走步骤 6→7→8 重渲重打**。
  - 若用户希望"以后查询该商品自动带图"，引导其去**下发工具「云图库 / 商品配图」**上传并绑定图片（该能力当前尚未暴露为 MCP 工具，需在下发工具界面内操作，绑定后下次 `query_item` 会直接返回真实图）。
- **用户不配图**：直接进入步骤 9 询问是否存模板。

注意：仅**带商品图**的海报（单品 / 多品 / 彩页）才可能有此提示；纯文字海报（`poster-text`）本就无商品图，不提示。

### 9. 保存为模板（建议主动询问）

打印完成后，主动问用户一句：**"要不要把这张海报存成模板？下次可以直接用模板再打一张"**。

用户同意就调用 `save_poster_template`：
- `name`：模板名，建议"活动名+类型+用途"，如 `国庆大促-单品海报-榴莲`
- `image_path`：刚生成的海报 png（也可用 `image_base64`）
- `html`：**必须传"渲染该海报所用 HTML 文件的【完整源文本字符串】"**（见下方"正确传 html"）；不传也行，但存了 html 才能以后改内容重渲染。
  **关键：入库的 html 必须保留 `{{...}}` 占位符（商品名/价格/门店一律用占位符），绝不能把真实数据写死**——否则模板在海报模块里永远显示生成时的旧数据，换商品也不刷新（详见模板格式契约）。
- `note`：备注，如 "单品海报/中秋主题"

#### 正确传 `html`（极易出错，务必遵循）
1. 先把渲染用的 HTML 落盘为本地文件（如 `poster.html`）；
2. **读取该文件的全部内容**（字符串），把这段文本作为 `html` 参数值；
3. `html` 必须是 `string` 类型：**不要传文件名、不要传对象/JSON/字典**。
   - 错误示例：传 `{head:..., body:...}` 或 `poster.html` → 工具会存成 `[object Object]`（18 字节空壳），模板彻底损坏（已多次出现此问题）。
   - 错误示例：传图片/JSON 对象 → 同样变 `[object Object]`。
4. **让模板自包含（强烈建议）**：保存前先把 HTML 里所有相对图片路径（`branch_logo.png`/`item1.png`/`hero_bg.png`/`qrcode.png` 等）替换成 **base64 data URI**（`data:image/png;base64,xxxxx`），再传 html。否则复用模板时这些图不在 PosterTemplate 目录、重渲染会丢图。base64 图片来自上一步下载到工作目录的本地文件（file→base64 编码即可）。

**下次复用**（用户说"用上次那个模板""按之前的海报再打一张"）：
1. 先 `list_poster_templates` 拿到模板名（可带 `keyword` 过滤）；
2. 再 `poster_print(template="国庆大促-单品海报-榴莲", qrcode_text=branch_url, qrcode_size=25)`，**不用重新生成图**（直接打印已存的 png）；
3. 若要换商品/价格等内容，用 `list_poster_templates(with_thumb=1)` 取回 `html` 修改重渲染，或走正常流程重新生成。

打印前若不确定目标机（门店常有多台：A4 激光 / 标签机 / 网络机），先调 `query_printer`：
- 优先选 `default=true` 那台；
- 或按名称/驱动关键字匹配（如含 "HP"、"标签"）；
- 若 `poster_print` 返回"未找到打印机"，错误信息里会带上**本机可用打印机列表与系统默认机**，按它重试即可。
- 若返回里出现 `ret_warn`（例如"目标打印机是虚拟/传真打印机，可能不会真正出纸"），说明打到了 PDF/传真机上：改用 `query_printer` 里 `virtual=false` 且 `offline=false` 的实体机重打。

## 关键注意事项

- **keyword 是拼音助记码**，不是中文。查不到商品时换拼音首字母试。
- **先定类型再写 HTML**：从 assets 复制模板填数据，不要每次从零手写。
- **门店信息必须从 MCP 查询**，不要硬编码店名。
- **模板用 `{{...}}` 占位符而非写死数据**（商品/门店/价格一律占位），否则保存的模板在海报模块换商品不刷新。契约见 [references/poster-template-format.md](references/poster-template-format.md)。
- **价格列名是 `sub_price`(售价)/`spec_price`(特价)/`org_price`(原价)**，不是 `item_sale_price` 之类（缓存表里不存在，取到空）。
- **商品名必须与图片对应**，渲染后检查。
- **布局用 CSS Grid/Flex**，不要用绝对定位叠加 AI 背景。
- **价格标签**用黄色/红色高对比，原价划线。
- 工作目录：使用当前会话的工作目录（或系统临时目录），不要写死本机路径。

## 参考文件

- 各类型海报排版规范与美观要点见 [references/poster-types.md](references/poster-types.md)
- 彩页详细布局规范见 [references/poster-layout.md](references/poster-layout.md)
- **数据驱动模板占位符契约（必须遵循）见 [references/poster-template-format.md](references/poster-template-format.md)**
- MCP 工具参数详情见 [references/mcp-api.md](references/mcp-api.md)
