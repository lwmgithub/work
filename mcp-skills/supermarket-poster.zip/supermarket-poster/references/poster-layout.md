# 海报布局规范（整版彩页 poster-flyer.html）

> 其他类型（单品/多品/文字）的排版规格见 [poster-types.md](poster-types.md)。

## 画布
- 尺寸：1240×1754px（A4 竖版）
- 字体：Microsoft YaHei / SimHei
- 主色：#2DB84D（超市绿）、#E53935（促销红）、#FFD600（价格黄）

## 分区结构（从上到下）

### 1. 顶部白栏（高 115px）
- 白色背景，上下红色边框（4px）
- 左侧：门店 logo（75×75）+ 门店名（40px 红色加粗）+ 标语（13px 灰色）
- 中间：红色圆角信息框（活动时间、地址、电话）
- 右侧：二维码位（65×65）+ "扫码线上领券"；二维码由 `poster_print(qrcode_text=...)` 叠加（默认右下角），HTML 里可只留文字与空位

### 2. 主视觉区（高 370px）
- 可用 AI 生成卡通背景图（绿色调、卡通工人/购物车人物、礼物盒、气球）
- 中间叠加立体标题：
  - 第一行："周末特惠"（白色+黄色，82px，3px 深绿描边）
  - 英文："WEEKEND SPECIAL"（黄色 26px）
  - 第二行："疯狂嗨购"（白色，82px，3px 深绿描边）
- 下方 5 个彩色标签：低价(蓝)、满意(橙)、优质(粉)、贴心(紫)、新鲜(绿)

### 3. 精选推荐区（高 400px）
- 左侧竖排标签："精选推荐 SALE"
- CSS Grid 5列×2行，gap 8px
- 每个商品卡片：
  - 白色圆角背景，商品图填满
  - 右上角：红色"每人限购X斤"
  - 右侧飘带：黄色"超值推荐"或红色"惊爆价"
  - 左下角：商品名（13px 黑色）
  - 右下角：黄色价格标签（22px 红色价格 + 11px 单位）

### 4. 圆形惊爆价区（高 170px）
- 5 个圆形商品图（115px，黄色边框）
- 圆形底部叠加红色圆形价格牌（82px）
- 下方商品名（13px 白色）

### 5. 底部三栏区（高约 600px）
- 3 列等宽，白色圆角卡片
- 每栏标题：装饰性字体 + 红色大字
- 每栏内 2×2 商品网格
- 商品：图片 + 名称 + 黄色价格标签

## CSS 关键技巧

### 立体描边文字
```css
color: #fff;
-webkit-text-stroke: 3px #1B7A33;
text-shadow: 5px 5px 0 #1B7A33, 8px 8px 15px rgba(0,0,0,0.3);
```

### 飘带效果
```css
.ribbon {
  position: absolute; top: 28%; right: -5px;
  background: #FFD600; color: #E53935;
  padding: 2px 10px 2px 8px;
  transform: rotate(-5deg);
}
```

### Chrome 渲染命令
```
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --headless --disable-gpu `
  --screenshot="输出.png" --window-size=1240,1754 `
  --default-background-color=FFFFFFFF `
  "file:///HTML路径"
```
