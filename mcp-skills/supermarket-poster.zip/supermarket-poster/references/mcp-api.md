# bw-scale MCP 接口参考

## Endpoint
```
http://127.0.0.1:7688/mcp
```
POST JSON-RPC 2.0

## 调用方式

### 通过 MCP 工具
直接调用 `mcp__bw_scale__query_shop`、`mcp__bw_scale__query_item`、`mcp__bw_scale__poster_print`、`mcp__bw_scale__get_qrcode`、`mcp__bw_scale__query_printer`、`mcp__bw_scale__save_poster_template`、`mcp__bw_scale__list_poster_templates`、`mcp__bw_scale__query_cloud_templates`。

### 通过 HTTP 直调（MCP 工具不可用时）
```powershell
$body = '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"<tool>","arguments":{...}}}'
Invoke-RestMethod -Uri "http://127.0.0.1:7688/mcp" -Method Post -Body $body -ContentType "application/json" -TimeoutSec 15
```

## 工具列表

### query_shop
查询当前门店信息，无参数。

返回：`ret_code` + **`ret_data`**（门店字段都在 `ret_data` 内，例如 `ret_data.branch_url`）：
- `branch_id` / `branch_no`：门店编号
- `branch_name`：门店名称
- `branch_tel`：联系电话
- `branch_addr`：门店地址
- `branch_url`：线上商城 URL
- `branch_memo`：门店备注
- `branch_logo_base64`：门店 logo PNG base64

### query_item
查询商品。关键参数：
- `keyword`：搜索关键词，**匹配拼音助记码**（如 BLM=菠萝蜜），不是中文
- `only_spec`：1=只查特价商品
- `limit`：返回条数（默认 20）
- `fields`：指定返回字段

返回商品列表，含：商品名称、条码、价格、单位、图片等。

### get_qrcode
把文本（如 `branch_url`）生成本地二维码图片，离线可用。
- `text`：二维码内容（必填）
- `size`：期望边长(px)，默认 300
- `quiet`：静区模块数，默认 4
- `format`：`base64`(默认，返回 `image_base64`) / `path`(返回 `image_path` 落地文件)

### save_poster_template
把生成好的海报存为模板，便于以后复用。
- `name`：模板名称（必填，中文/字母/数字均可）
- `image_path` / `image_base64`：海报图（二选一）
- `html`：可选，生成该海报的 **HTML 源文本（字符串）**。必须传字符串：即渲染用 .html 文件的完整内容；不要传文件名、不要传对象/JSON（会存成 `[object Object]` 空壳）。建议先把相对图片路径就地改成 base64 data URI，使模板自包含可重渲染。
- `note`：可选备注
- `overwrite`：`1`(默认)覆盖同名；`0` 同名报错

返回：`name` / `image_path` / `html_path`(如传了 html) / `width` / `height`

模板存放目录：`<下发工具目录>\PosterTemplate\`（一个模板 = 图 + 同名 `.json` + 可选 `.html`）

### list_poster_templates
列出已保存的海报模板。
- `keyword`：可选，按模板名/备注过滤
- `with_thumb`：`1` 返回缩略图 `thumb_base64`（默认 0）

返回：`count` / `template_dir` / `templates[]`（`name` / `image_path` / `width` / `height` / `created` / `branch_name` / `note` / `has_html`）

### query_printer
查询本机可用打印机（含已连接的网络打印机）。可选参数：`keyword`（按 名称/驱动/端口 过滤）。

返回：
- `default`：系统默认打印机名
- `count`：台数
- `printers[]`：`name` / `default`(是否默认) / `offline`(是否脱机) / `network`(是否网络机) / `virtual`(是否虚拟/传真机：PDF、XPS、Fax、OneNote、WPS 等) / `driver` / `port`

用途：选打印目标机；排查"打印没反应"（看 `offline`、驱动、端口）。

**选机建议**：优先选 `virtual=false` 且 `offline=false` 的实体机；若 `default=true` 那台是 `virtual=true`（如"导出为WPS PDF"），**不要**直接用它打印海报。

### poster_print
打印海报图片。
- `image_path`：图片本地绝对路径
- `template`：海报模板名（来自 `list_poster_templates`）；与 `image_path` 二选一，仍可叠二维码
- `qrcode_text`：二维码内容（如 `branch_url`），留空不叠加；本软件直接把二维码叠到海报上
- `qrcode_pos`：`bottom-right`(默认) / `top-right` / `top-left` / `bottom-left` / `center`
- `qrcode_size`：二维码边长(mm)，默认 30
- `qrcode_margin`：距页边距(mm)，默认 5
- `printer`：打印目标机名（取值来自 `query_printer`；留空=系统默认打印机；名字不存在时错误信息会返回可用列表）
- `fit`：`page`（整页适配）
- `orientation`：`portrait`（竖版）
- `copies`：份数

### query_cloud_templates
查询云端模板市场（智百威云模板库）中的海报模板，供 AI 浏览 / 筛选可下载的海报模板。
- `keyword`：可选，按模板名模糊搜索
- `mod_style`：样式过滤，默认 `pst_html_pop_style`（海报）
- `soft_ver`：软件版本标识过滤，默认 `pstapp`
- `is_share`：是否共享：`1`(默认) / `0`
- `is_my`：是否仅本人上传：`1` / `0`(默认)
- `mod_flag`：可选，模板标记过滤
- `uploader`：可选，按上传者过滤
- `page_index`：页码，默认 1
- `page_size`：每页条数，默认 20，最大 50

返回：`ret_code` / `cloud_ok`(云端是否成功) / `ret_total` / `ret_page` / `ret_page_size` / `ret_count` / `ret_data[]`（每条含 `tpl_uid`、`tpl_name`、`tpl_style`、`soft_ver`、`uploader`、`upload_date`、`score`、`status`、`is_share`、`img_file`、`img_url`、`tpl_file`、`tpl_url`；`img_url`/`tpl_url` 为云端绝对地址，可直接下载预览）。

用途：让 AI 向用户列举 / 推荐云端共享海报模板。把模板真正下载并导入「下发工具-海报模块」通常在云市场界面（GUI）完成，本接口只负责查询列举，不执行下载 / 导入。

## 常见问题

- **keyword 搜不到商品**：换拼音首字母试，如查"菠萝蜜"用 BLM
- **MCP 连接失败**：确认西银软件已启动并登录
- **打印无反应**：检查打印机是否在线、纸张是否就绪
- **二维码扫不出来**：确认传了 `qrcode_text`（或 `get_qrcode` 的 `format=path` 图片路径正确），二维码边长建议 ≥25mm

## 安装与生效（按AI助手区分）

- **目录扫描型**（TRAE / CodeBuddy / QwenWork / WorkBuddy / Codex / Qoder 等）：技能包解压到用户技能目录即生效，重启助手后加载。
- **豆包（桌面版 Doubao / 办公版 DoubaoWork）**：技能为**云端登记**制——豆包按账号云端的技能清单（带云端 id）同步本地副本，仅把目录复制进 `.user_skills` 不会被加载。请在豆包的技能页导入，或把技能包 zip 直接拖进对话窗口，由豆包注册后生效。
- **连接器**：每个助手都要单独配置 `bw-scale` MCP 连接器（或用 HTTP 直调 `http://127.0.0.1:7688/mcp`），否则技能无法查询门店/商品、也无法打印。

> 判断是否生效：在豆包类助手中问"你现在有哪些技能"，或看它是否调用 `query_shop` / `poster_print`；只做图像生成、不调用工具，说明技能未加载或连接器未配置。
